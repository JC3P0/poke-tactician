"""
Pokemon Battle Optimizer Package
CS_311 Extra Credit Project
"""

# Import the handler for Netlify to find
from .battleOptimizer import handler

__all__ = ['handler']
